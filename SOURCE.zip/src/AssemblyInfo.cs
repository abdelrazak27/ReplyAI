﻿using System.Reflection;
[assembly: AssemblyTitle("Reply AI")]
[assembly: AssemblyProduct("Reply AI")]
[assembly: AssemblyVersion("2.2.1.0")]
[assembly: AssemblyFileVersion("2.2.1.0")]
