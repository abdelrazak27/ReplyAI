﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace ParoleRP {
 public sealed partial class Desktop {
  TextBlock connectionFeedback;
  Button SmallButton(string label,Action action,bool primary=false){var button=Button(label,action,primary);button.Padding=new Thickness(11,7,11,7);button.Margin=new Thickness(8,0,0,0);return button;}
  void ConnectionFeedback(string message,bool error=false){if(connectionFeedback!=null){connectionFeedback.Text=message;connectionFeedback.Visibility=String.IsNullOrEmpty(message)?Visibility.Collapsed:Visibility.Visible;connectionFeedback.Foreground=B(error?"#D0AE78":"#E8E5DF");}Note(message);}
  void Settings(){
   var vault=new ConnectionVault(store.Root);var entries=vault.Load();ApiConnection main=null;string keyError="";if(store.HasKey){try{main=new ApiConnection{Name="Clé principale",Provider="Groq",Key=store.GetKey(),Model=data.Settings.Model,QuotaGroup=data.Settings.QuotaGroup};}catch{keyError="Clé principale illisible. Remplace-la depuis son menu.";}}
   var heading=new Grid{Margin=new Thickness(0,0,0,18)};heading.ColumnDefinitions.Add(new ColumnDefinition());heading.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
   heading.Children.Add(T("Mes clés Groq",27));var add=SmallButton("+ Ajouter une clé",()=>EditConnection(null,main==null),true);Grid.SetColumn(add,1);heading.Children.Add(add);host.Children.Add(heading);
   var list=S();
   list.Children.Add(ConnectionRow(main,true,0));for(int i=0;i<entries.Count;i++)list.Children.Add(ConnectionRow(entries[i],false,i));
   var fallback=new CheckBox{Content="Secours automatiques si quota atteint",IsChecked=data.Settings.FallbackEnabled,ToolTip="Utilise les clés de secours cochées dans l’ordre de la liste. Budget total : 10 secondes."};
   fallback.Checked+=(s,e)=>{data.Settings.FallbackEnabled=true;revision++;Persist();};fallback.Unchecked+=(s,e)=>{data.Settings.FallbackEnabled=false;revision++;Persist();};
   var bottom=new Grid{Margin=new Thickness(0,12,0,0)};bottom.ColumnDefinitions.Add(new ColumnDefinition());bottom.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});bottom.Children.Add(fallback);
   var links=Row(SmallButton("Créer une clé ↗",()=>OpenUrl("https://console.groq.com/keys")),SmallButton("Quotas ↗",()=>OpenUrl("https://console.groq.com/settings/limits")));Grid.SetColumn(links,1);bottom.Children.Add(links);
   var keysCard=Card(S(new ScrollViewer{Content=list,MaxHeight=285,VerticalScrollBarVisibility=ScrollBarVisibility.Auto},bottom));keysCard.Padding=new Thickness(23,14,23,14);host.Children.Add(keysCard);
   var shortcut=ShortcutRecorder(false,false,ConnectionFeedback);shortcut.Width=245;shortcut.HorizontalAlignment=HorizontalAlignment.Left;
   var mini=new CheckBox{Content="Réduire près de l’horloge",IsChecked=data.Settings.MinimizeToTray};mini.Checked+=(s,e)=>{data.Settings.MinimizeToTray=true;Persist();};mini.Unchecked+=(s,e)=>{data.Settings.MinimizeToTray=false;Persist();};
   shortcutDiagnostic=T(ShortcutSummary(),12,"#989892");
   var diagnostic=new Expander{Header="Diagnostic du raccourci",Margin=new Thickness(0,10,0,0),Foreground=B("#989892"),Content=S(Space(12),shortcutDiagnostic,Button("Actualiser",()=>{Register();Header();shortcutDiagnostic.Text=ShortcutSummary();}))};
   var shortcutRow=new Grid();shortcutRow.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});shortcutRow.ColumnDefinitions.Add(new ColumnDefinition());shortcutRow.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});var shortcutLabel=T("Correction",14);shortcutLabel.Width=76;shortcutLabel.VerticalAlignment=VerticalAlignment.Center;shortcutLabel.Cursor=System.Windows.Input.Cursors.Hand;shortcutLabel.MouseLeftButtonDown+=(s,e)=>shortcut.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Button.ClickEvent));shortcutRow.Children.Add(shortcutLabel);shortcut.Margin=new Thickness(18,0,12,0);Grid.SetColumn(shortcut,1);shortcutRow.Children.Add(shortcut);Grid.SetColumn(mini,2);shortcutRow.Children.Add(mini);host.Children.Add(Card(S(shortcutRow,Space(12),RephraseShortcutSettings(),Space(12),GenerationShortcutSettings(),diagnostic)));
   connectionFeedback=T(keyError,12,keyError.Length==0?"#E8E5DF":"#D0AE78");connectionFeedback.Visibility=keyError.Length==0?Visibility.Collapsed:Visibility.Visible;host.Children.Add(connectionFeedback);
  }
  UIElement ConnectionRow(ApiConnection entry,bool primary,int index){
   var row=new Grid();row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(26)});row.ColumnDefinitions.Add(new ColumnDefinition());row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(118)});row.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});row.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
   if(primary){var dot=T("●",11,"#E8E5DF");dot.VerticalAlignment=VerticalAlignment.Center;row.Children.Add(dot);}else{var enabled=new CheckBox{Tag=entry.Id,IsChecked=entry.Enabled,VerticalAlignment=VerticalAlignment.Center,ToolTip="Utiliser cette clé en secours"};enabled.Checked+=(s,e)=>{SetConnectionEnabled(entry.Id,true);entry.Enabled=true;};enabled.Unchecked+=(s,e)=>{SetConnectionEnabled(entry.Id,false);entry.Enabled=false;};row.Children.Add(enabled);}
   var name=T(primary?"Clé principale":entry.Name,14);name.TextWrapping=TextWrapping.NoWrap;name.TextTrimming=TextTrimming.CharacterEllipsis;
   var caption=T(entry==null?"À configurer":(primary?"Principale":"Secours "+(index+1))+" · "+ConnectionDisplay.ModelLabel(entry.Model),11,"#989892");caption.TextWrapping=TextWrapping.NoWrap;caption.TextTrimming=TextTrimming.CharacterEllipsis;
   var identity=S(name,Space(3),caption);identity.VerticalAlignment=VerticalAlignment.Center;identity.Margin=new Thickness(0,0,14,0);identity.ToolTip=entry==null?null:"Compte : "+entry.QuotaGroup;Grid.SetColumn(identity,1);row.Children.Add(identity);
   var suffix=T(ConnectionDisplay.KeySuffix(entry==null?null:entry.Key),12,"#989892");suffix.FontFamily=new FontFamily("Consolas");suffix.VerticalAlignment=VerticalAlignment.Center;suffix.TextWrapping=TextWrapping.NoWrap;Grid.SetColumn(suffix,2);row.Children.Add(suffix);
   var test=SmallButton("Tester",()=>{});test.IsEnabled=entry!=null;test.Click+=async(s,e)=>{if(entry==null||busy||capturing)return;busy=true;host.IsEnabled=false;RefreshGlobalState();ConnectionFeedback("Test en cours…");try{var timer=System.Diagnostics.Stopwatch.StartNew();await api.TestConnection(entry);ConnectionFeedback("Connexion validée · "+(timer.ElapsedMilliseconds/1000.0).ToString("0.00")+" s");}catch(Exception ex){ConnectionFeedback(ex.Message,true);}finally{busy=false;host.IsEnabled=true;RefreshGlobalState();}};Grid.SetColumn(test,3);row.Children.Add(test);
   var more=SmallButton("⋯",()=>{});more.ToolTip="Modifier, réordonner ou supprimer";more.Click+=(s,e)=>{var menu=new ContextMenu();var edit=new MenuItem{Header=entry==null?"Ajouter la clé principale":"Modifier"};edit.Click+=(a,b)=>EditConnection(entry,primary);menu.Items.Add(edit);if(!primary){var up=new MenuItem{Header="Monter",IsEnabled=index>0};up.Click+=(a,b)=>MoveConnection(entry.Id,-1);menu.Items.Add(up);var down=new MenuItem{Header="Descendre",IsEnabled=index<new ConnectionVault(store.Root).Load().Count-1};down.Click+=(a,b)=>MoveConnection(entry.Id,1);menu.Items.Add(down);}if(entry!=null||(primary&&store.HasKey)){menu.Items.Add(new Separator());var remove=new MenuItem{Header="Supprimer"};remove.Click+=(a,b)=>Safe(()=>RemoveConnection(entry,primary));menu.Items.Add(remove);}menu.PlacementTarget=more;menu.IsOpen=true;};Grid.SetColumn(more,4);row.Children.Add(more);
   return new Border{Child=row,Padding=new Thickness(0,8,0,8),BorderBrush=B("#383836"),BorderThickness=new Thickness(0,0,0,1)};
  }
  void SetConnectionEnabled(string id,bool enabled){var vault=new ConnectionVault(store.Root);var list=vault.Load();list.Single(c=>c.Id==id).Enabled=enabled;vault.Save(list);revision++;}
  void MoveConnection(string id,int delta){Safe(()=>{var vault=new ConnectionVault(store.Root);var list=vault.Load();int before=list.FindIndex(c=>c.Id==id),after=before+delta;if(before<0||after<0||after>=list.Count)return;var item=list[before];list.RemoveAt(before);list.Insert(after,item);vault.Save(list);revision++;Render();});}
  void RemoveConnection(ApiConnection entry,bool primary){if(MessageBox.Show(w,"Supprimer cette clé enregistrée ?","Clé API",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;if(primary)store.RemoveKey();else{var vault=new ConnectionVault(store.Root);var list=vault.Load();list.RemoveAll(c=>c.Id==entry.Id);vault.Save(list);}revision++;Header();Render();ConnectionFeedback("Clé supprimée de ce PC.");}
 }
}
